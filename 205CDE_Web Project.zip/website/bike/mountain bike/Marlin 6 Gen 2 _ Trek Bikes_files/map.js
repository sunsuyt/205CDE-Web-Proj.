var lcly_query_string_0            = 'company_name=Trek&button_text=%3Aheart%3A&button_id=HTML&company_id=3480&css=6&color_0=%23999999&upc=601842581568&n_related_styles=3&show_location_switcher=1&show_location_prompt=1&lang=en-us&show_dealers=1&n_dealers=2&show_only_upc_stocking_dealers=1&link_opens_modal=1&show_address=1&show_directions=1&show_phone=1&no_link=0&hide_all_when_no_stock=0&only_show_country=US&radius_in_miles=200&dealers_company_id=3480&v=1679893060&is_reload=1&zoom=9&product_id=1311317';
var lcly_orig_query_string_0       = 'company_name=Trek&button_text=%3Aheart%3A&button_id=HTML&company_id=3480&css=6&color_0=%23999999&upc=601842581568&n_related_styles=3&show_location_switcher=1&show_location_prompt=1&lang=en-us&show_dealers=1&n_dealers=2&show_only_upc_stocking_dealers=1&link_opens_modal=1&show_address=1&show_directions=1&show_phone=1&no_link=0&hide_all_when_no_stock=0&only_show_country=US&radius_in_miles=200&dealers_company_id=3480&v=1679893060&is_reload=1&zoom=9&product_id=1311317';
var lcly_orig_query_string_obj_0   = {"company_name":"Trek","button_text":":heart:","button_id":"HTML","company_id":"3480","css":"6","color_0":"#999999","upc":"601842581568","n_related_styles":"3","show_location_switcher":"1","show_location_prompt":"1","lang":"en-us","show_dealers":"1","n_dealers":"2","show_only_upc_stocking_dealers":"1","link_opens_modal":"1","show_address":"1","show_directions":"1","show_phone":"1","no_link":"0","hide_all_when_no_stock":"0","only_show_country":"US","radius_in_miles":"200","dealers_company_id":"3480","v":"1679893060","is_reload":"1","zoom":"9","product_id":"1311317"};
var lcly_parent_0                  = document.getElementById('lcly-button-0');
var lcly_link_0                    = document.getElementById('lcly-link-0');
var lcly_button_0                  = document.createElement('a');
var lcly_location_switcher_input_0 = null;
var lcly_orig_endpoint_0 	 	   = 'https://www.locally.com/start_conversion?action=convert';
var lcly_orig_modal_title_0        = '';
var lcly_toggle_state_0			   = 'open';
var lcly_launch_pl_v3                      = true;
var lcly_query_has_product_0       = lcly_orig_query_string_0.indexOf('product_id=') > -1;    
window.__lcly_user_lang					   = `en-us`; 


lcly_button_0.className = 'lcly-primary-trigger lcly-wo-dealers ';
lcly_button_0.setAttribute('title', 'Buy it Locally');
lcly_button_0.setAttribute('data-switchlive', 'true');
lcly_button_0.setAttribute('data-switchlive-mode', 'auto');
lcly_button_0.setAttribute('data-switchlive-id-PL', '6');
lcly_button_0.setAttribute('id', 'lcly-button-buy');
lcly_button_0.setAttribute('tabindex', '0');
lcly_button_0.setAttribute('role', 'button');

lcly_link_0.className 			   = 'lcly-anchor lcly-toggleable-0';
var city_placeholder						= '';

lcly_parent_0.setAttribute('tabindex', '0');

lcly_parent_0.addEventListener("keydown", function(e) {
	const keyD = e.key !== undefined ? e.key : e.keyCode;
	if (keyD === "Enter" || keyD === 13) {
		e.preventDefault();
		if(document.getElementById('lcly-button-buy')){
			document.getElementById('lcly-button-buy').click();
		}
	}
}); 


lcly_link_0.parentNode.insertBefore(lcly_button_0, lcly_link_0);

lcly_link_0.style.fontFamily		= 'Verdana';
lcly_link_0.style.fontSize			= '11px';
lcly_link_0.style.color				= '#707070';
lcly_link_0.style.textDecoration	= 'none';
lcly_link_0.style.fontWeight		= 'normal';
lcly_link_0.style.marginTop			= '5px';
lcly_link_0.style.display			= 'block';
lcly_link_0.style.lineHeight		= '12px';

	lcly_link_0.innerHTML 		= 'Find Marlin 6 Gen 2. Locally.';
	lcly_link_0.setAttribute('href', 'https://www.locally.com//product/1311317/trek-marlin-6-gen-2');

	var lcly_css_0 = document.createElement('style');
	lcly_css_0.innerHTML = 'a.lcly-primary-trigger {float: left;width: 100%;clear: both;margin: 0 0 10px 0;}a.lcly-primary-trigger span {line-height: 60px;display: block;background: #999999;height: 60px;text-align: center;color: #fff;font-size: 23px;}a.lcly-primary-trigger span:hover {background-color: #eee;color: #999999;}.lcly-anchor {display: block;clear: both;text-align: center;margin: 0 0 10px 0;}.lcly-dealers-wrap {float: left;clear: both;width: 100%;box-sizing: border-box;font-size: 12px;margin: 10px 0 0 0;}.lcly-dealer {float: left;width: 100%;box-sizing: border-box;background: #f9f9f9;margin: 0 0 7px 0;padding: 8px 10px 10px 32px;position: relative;text-align: left;}.lcly-dealer .lcly-icon-marker {position: absolute;top: 9px;left: 7px;font-size: 17px;fill: #AFAFAF;width: 15px;height: 15px;}.lcly-dealer-name {font-weight: bold;font-size: 12px;margin: 0 0 5px 0;line-height: 11px;width: 75%;}.lcly-dealer-distance {position: absolute;top: 9px;right: 11px;font-size: 10px;color: #777;}.lcly-dealer:hover {background: #eee;cursor: pointer;}.lcly-dealer-stock {font-size: 10px;line-height: 13px;}.lcly-tabs {background: #A1A1A1;margin: 10px 0 0 0;border-bottom: 5px solid #A1A1A1;height: 26px;}.lcly-tabs a {display: block;color: #fff;font-size: 10px;width: 50%;box-sizing: border-box;float: left;line-height: 26px;text-decoration: none;background-color: #999999;padding: 0 0 0 10px;}.lcly-tabs a.active {background: #EEEEEE;color: #000;}.lcly-tabs a:hover {background: #fff;color: #999999;}.lcly-tabs a.active:hover {background: #A1A1A1;color: #fff;}.lcly-tab {padding: 0 0 0 10px;}.lcly-related-product {box-sizing: border-box;width: 100%;float: left;clear: both;background: #eee;padding: 6px 8px 6px 8px;margin: 0;}.lcly-related-img {float: left;width: 79px;margin: 0 8px 0 0;}.lcly-related-img img {width: 100%;}.lcly-related-info {text-align: left;font-size: 11px;box-sizing: border-box;margin: 0;line-height: 17px;}.lcly-related-products-wrap {float: left;width: 100%;clear: both;box-sizing: border-box;padding-bottom: 0;background: #eee;margin: 0 0 10px 0;}.lcly-related-name {font-weight: bold;font-size: 12px;}.lcly-related-product:hover {background: #eee;cursor: pointer;}.lcly-related-in-stock-notice i {display: block;float: left;margin: 3px 4px 0 0;}.lcly-related-link a {color: #333;font-weight: bold;text-decoration: none;}.lcly-location-switcher-input {width: 100% !important;height: 32px !important;line-height: 32px !important;box-sizing: border-box !important;padding: 0 6px !important;border: 1px solid #ddd !important;border-width: 1px 0 1px 1px !important;font-size: 16px !important;color: #333 !important;}.lcly-location-switcher-wrap {width: 100%;box-sizing: border-box;clear: both;margin: 10px 0;height: 32px;overflow: hidden;white-space: nowrap;font-size: 16px;}.lcly-location-switcher-a {float: left;width: 60%;box-sizing: border-box;}.lcly-location-switcher-b {float: right;width: 40%;}.lcly-location-switcher-b input {width: 100%;height: 32px;line-height: 20px;background: #ddd;cursor: pointer;padding: 0;margin: 0;color: #777;font-size: 16px;border: none;}.lcly-location-switcher-b input:hover {background-color: #333;color: #fff;}.lcly-location-prompt {font-size: 11px; color: #666; text-decoration: none; font-weight: normal; margin-top: 10px; line-height: 12px;}.lcly-location-prompt a {color: #999999;margin: 0 0 0 10px;text-decoration: underline;}.lcly-icon-check-mark-circle {width: 12px;height: 12px;margin: 3px 4px 0 0;display: block;float: left;}.lcly-icon-check-mark {font-size: 12px;width: 13px;height: 13px;display: block;float: left;margin: 0 4px 10px 0;fill: #71ae2b;}.lcly-no-dealers, .lcly-no-stock {background: #eee;padding: 10px 20px;margin: 0 0 10px 0;}.lcly-no-dealers p, .lcly-no-stock {margin: 11px 0;line-height: 16px;font-size: 11px;display: block;}.lcly-no-stock {margin: 0;background: none;padding: 0px 5px 5px 5px;}.lcly-dealer-directions {float: right;font-size: 11px;}.lcly-product-name {font-size: 20px;}.lcly-dealer-w-stock .lcly-dealer-stock {color: #71ae2b;}svg.icon-locally-outline {height: 22px;width: 22px;fill: #ffffff;background: none;padding: 0;float: none;margin: 0;display: inline-block;}a.lcly-primary-trigger {float: left;width: auto;text-decoration: none;box-sizing: border-box;text-align: center;margin: 10px 0 0 0;}a.lcly-primary-trigger span {line-height: 0;display: block;background: none;height: auto;text-align: left;color: #999999;}a.lcly-primary-trigger span:hover {background: none;}svg.icon-locally-outline {height: 21px;width: 21px;fill: #999999;background: none;padding: 0;float: none;margin: 5px 10px 0 0;display: inline-block;}a.lcly-primary-trigger em {font-weight: bold;display: block;font-size: 22px;font-style: normal;color: #EF8630;margin: 5px 0 0 0;line-height: 16px;}div#lcly-button-0 {margin: 15px 0 0 0;float: left;width: 100%;clear: both;}a.lcly-primary-trigger span {color: #333;font-size: 13px;}.lcly-location-switcher-outer {float: left;margin: 9px 0 0 0;}.lcly-tabs {clear: both;margin: 30px 0 0 0;float: left;width: 100%;}.lcly-location-switcher-b input {background: #999999 !important;color: #fff;height: 23px;text-transform: uppercase;font-size: 9px;}.lcly-location-switcher-input {font-size: 11px;height: 23px;padding: 0 9px;border-width: 1px !important;font-weight: normal;}.lcly-location-switcher-wrap {margin: 5px 0 0 0;height: 25px;}.lcly-location-switcher-b {width: 36%;}.lcly-dealers-wrap-outer,.lcly-related-products-wrap {display: block;float: left;width: 100%;margin-top: 0px;clear: both;background: none;}.lcly-dealers-wrap .lcly-dealer,.lcly-related-product {border: 1px solid #eee;display: block;float: left;width: 32.66%;min-height: 105px;padding: 9px 8px 10px 9px;background: #fff;clear: none;}.lcly-dealers-wrap .lcly-dealer .lcly-icon-marker {fill: #999999;top: 5px;right: 4px;left: auto;}.lcly-dealer .lcly-icon-marker {position: absolute;top: 9px;right: 4px;font-size: 17px;fill: #AFAFAF;width: 10px;height: 10px;}.lcly-dealers-wrap .lcly-dealer-name {color: #000;font-size: 12px;font-weight: bold;width: 96%;line-height: 13px;margin: 0 0 2px 0px;text-transform: none;}.lcly-dealers-wrap .lcly-dealer.w-3-dealers {margin: 0 0 0 1%;}.lcly-related-product {margin-right: .5%;}.lcly-dealers-wrap .lcly-dealer.w-2-dealers {width: 49.5%;margin: 0 0 0 1%;}.lcly-dealers-wrap .lcly-dealer.w-1-dealers {width: 100%;margin: 0;}.lcly-dealers-wrap-outer .lcly-dealers-wrap .lcly-dealer-n-0 {margin-left: 0;}.lcly-dealer-distance {position: relative;top: auto;right: auto;margin: 0 0 8px 0px;}.lcly-dealer-stock.lcly-has-in-stock-0 {color: #000;font-weight: bold;padding: 0;line-height: 10px;}.lcly-icon-check-mark {font-size: 12px;width: 13px;height: 19px;display: inline;float: left;margin: 0 1% 10px 0;}.lcly-dealers-wrap .lcly-dealer:hover {background: #eee;}.lcly-icon-check-mark-circle {fill: #23a4d0;}.lcly-tab {padding: 0 0 0 10px;}.lcly-tabs {width: 35%;border: 1px solid #ccc;margin: 10px 0 0px 0;overflow: hidden;height: 26px;border-bottom: none;}.lcly-tabs a.active {background: #fff;color: #333;}.lcly-tabs a {background: #ccc;}.lcly-dealer-stock {margin: 0;}.lcly-related-link a {color: #23a4d0;}.lcly-location-prompt {color: #999999;text-transform: none;font-weight: bold;font-size: 14px;text-align: left;}.lcly-location-prompt a {color: #999999;text-transform: lowercase;font-size: 11px;font-weight: normal;text-decoration: underline;}.lcly-location-features {margin: 5px 0 0 0;display: block;float: left;width: 90%;line-height: 12px;}.lcly-dealers-wrap-outer, .lcly-related-products-wrap {margin-bottom: 10px;}@media  screen and (max-width: 650px) {.lcly-tabs {display: block;clear: both;float: none;width: 100%;}.lcly-primary-trigger {margin: 0 0 20px 0;}.lcly-dealers-wrap .lcly-dealer,.lcly-related-product,.lcly-dealers-wrap .lcly-dealer.w-3-dealers,.lcly-dealers-wrap .lcly-dealer.w-2-dealers,.lcly-dealers-wrap .lcly-dealer.w-1-dealers {float: none;width: 100%;margin: 0 0 8px 0;min-height: 95px;}}.lcly-autocomplete-suggestions {position: absolute !important;border: 1px solid #ccc !important;background: #ddd !important;overflow: hidden !important;z-index: 9999 !important;font-size: 11px !important;white-space: nowrap !important;width: 220px !important;}.lcly-autocomplete-suggestion a {width: inherit !important;text-decoration: none !important;color: inherit !important;font-size : 16px !important;}.lcly-autocomplete-suggestion {font-family: Verdana, sans-serif;color: #555 !important;text-align: left !important;overflow: hidden !important;padding: 2px 5px !important;background-color: #fff;border-width: 0 1px !important;margin: -1px 0 0 0 !important;display: block !important;width: 100% !important;height: auto !important;}.lcly-autocomplete-suggestion:hover {background: #F0F0F0 !important;}.lcly-autocomplete-suggestion a:focus {outline: none !important;background: #eee !important;}.lcly-suggestions-ul {padding: 0 !important;margin: 0 !important;}.lcly-location-switcher-input {  margin-bottom: 0;}';
	lcly_parent_0.insertBefore(lcly_css_0, lcly_link_0);




		var lcly_location_switcher_0 = document.createElement('div');
	lcly_location_switcher_0.className = 'lcly-location-switcher-outer';
	lcly_location_switcher_0.innerHTML 	= 

		'<script id="lcly-jsonp-script"></script>'
		+ '<form id="lcly-location-switcher-0" autocomplete="off" class="lcly-location-switcher-wrap" style="display: none;">'
			+ '<div class="lcly-location-switcher-a">'
				+ '<input id="lcly-location-switcher-input-0" class="lcly-location-switcher-input" type="text" onkeyup="lcly_autofill_0(event)" onfocus="this.select()" onclick="this.setAttribute(\'placeholder\', \'\');" placeholder=", Hong Kong Island" aria-labelledby="lcly-location-prompt-link-0">'
					+ '<div id="lcly-suggestions-autocomplete"></div>'
			+ '</div>'
			+ '<div class="lcly-location-switcher-b">'
				+ '<input id="lcly-location-switcher-button-0" class="lcly-location-switcher-button" type="submit" value="Change">'
			+ '</div>'
		+ '</form><div id="lcly-location-prompt-0" class="lcly-location-prompt"><span class="lcly-location-prompt-label">Want it today in <span class=\"lcly-city-name\">, Hong Kong Island</span>?</span> <a id="lcly-location-prompt-link-0" class="lcly-location-prompt-link"data-switchlive="true"data-switchlive-mode="auto"data-switchlive-id-PL="5"href="javascript:;">Change</a></div>';

	lcly_parent_0.insertBefore(lcly_location_switcher_0, lcly_link_0);

	function lcly_jsonp_script_0(str) {
	if(typeof(str) === 'string' && str.trim() === '') {
		return;
	}
	var scriptNew = document.createElement("script");
	var scriptOld = document.getElementById("lcly-jsonp-script");
		scriptNew.id = scriptOld.id;
	scriptNew.type = "text/javascript";
	scriptNew.src = "https://www.locally.com/geo/suggest?query=" + str + "&callback=lcly_get_script_callback_0";
	document.getElementById("lcly-jsonp-script").parentNode.insertBefore(scriptNew, scriptOld);
	document.getElementById("lcly-jsonp-script").parentNode.removeChild(scriptOld);
}

function lcly_get_script_callback_0(response) {
 	var list = document.createElement("ul");
 	list.id = "lcly-suggestions-ul-0";
 	list.className = 'lcly-suggestions-ul';
 	if (response.suggestions != undefined) {
    	response.suggestions.forEach(function(val, i) {
    		var item = document.createElement("li");
    		var anchor = document.createElement("a");
    		anchor.setAttribute("href", "javascript:;");
    		anchor.className = "lcly-autocomplete-anchor";
			anchor.tabIndex = '0';
    		anchor.id = "lcly-autocomplete-a" + i;
    		item.appendChild(anchor);
    		anchor.appendChild(document.createTextNode(val.value));
    		list.appendChild(item);
    		item.className = "lcly-autocomplete-suggestion";
    		item.id = "lcly-suggest" + i;
    	})
 	}
 	//set width to input, if input small set suggestions width fixed
	var lcly_input_style = window.getComputedStyle(document.getElementById("lcly-location-switcher-input-0"));
	var lcly_width_fix = lcly_input_style.getPropertyValue("width");
	var lcly_raw_width = parseInt(lcly_width_fix.substr(0, lcly_width_fix.indexOf("px")), 10);
	if (lcly_raw_width < 125) {
		document.getElementById("lcly-suggestions-autocomplete").style.width = 225 + "px";
	}
	else {
		document.getElementById("lcly-suggestions-autocomplete").style.width = lcly_width_fix;
	}

     document.getElementById("lcly-suggestions-autocomplete").innerHTML = "";
     document.getElementById("lcly-suggestions-autocomplete").appendChild(list);
     document.getElementById("lcly-suggestions-autocomplete").className = "lcly-autocomplete-suggestions";
     //or querySelectorAll
     var listElems = document.getElementsByClassName("lcly-autocomplete-suggestion");

     //register keydown and mousedown handler for each list item
     for (i = 0; i < listElems.length;i++) {

     	listElems[i].addEventListener('click', function(e) {
			//stopping event(click) propagation.
			e.stopPropagation();
     		document.getElementById("lcly-location-switcher-input-0").value = document.getElementById(this.firstChild.id).innerHTML;

     		//sets actual value, above sets nominal value
     		document.getElementById("lcly-location-switcher-input-0").setAttribute("value", document.getElementById(this.firstChild.id).innerHTML);

     		document.getElementById("lcly-suggestions-ul-0").style.display = "none";
     		document.getElementById("lcly-location-switcher-input-0").focus();

     		document.getElementById("lcly-location-switcher-button-0").click();
     	});
			
			listElems[i].addEventListener("keydown",function(e) {
				e.preventDefault();
				var codeA = e.keyCode ? e.keyCode : e.charCode;
			
			if (codeA === 38 || codeA === 9) {
				var strA = this.firstChild.id;
				var numA = strA.charAt(strA.length - 1);
				if (parseInt(numA, 10) === 0) {
					document.getElementById("lcly-location-switcher-input-0").focus();
					document.getElementById("lcly-location-switcher-input-0").select();
				}
				else {
					var strNew = strA.slice(0, -1);
					var realNumA = parseInt(numA, 10);
					realNumA -= 1;
					strNew += realNumA;
					document.getElementById(strNew).focus();
					document.getElementById("lcly-location-switcher-input-0").value = document.getElementById(strNew).innerHTML;
				}
			}
			
			if (codeA === 40 || codeA === 9) {
				var strA = this.firstChild.id;
				var numA = strA.charAt(strA.length - 1);
				if (parseInt(numA, 10) === listElems.length - 1) {
					document.getElementById("lcly-location-switcher-input-0").focus();
					document.getElementById("lcly-location-switcher-input-0").select();
				}
				else {
					var strNew = strA.slice(0, -1);
					var realNumA = parseInt(numA, 10);
					realNumA += 1;
					strNew += realNumA;
					document.getElementById(strNew).focus();
					document.getElementById("lcly-location-switcher-input-0").value = document.getElementById(strNew).innerHTML;
					}
				
     		}
     		if (codeA === 13) {
     			document.getElementById("lcly-location-switcher-input-0").value = document.getElementById(this.firstChild.id).innerHTML;
     			//sets actual value, above sets nominal value
     			document.getElementById("lcly-location-switcher-input-0").setAttribute("value", document.getElementById(this.firstChild.id).innerHTML);
     			document.getElementById("lcly-suggestions-ul-0").style.display = "none";
     			document.getElementById("lcly-location-switcher-button-0").click();
     		}
		});
	}
}
 
function lcly_autofill_0(e) {
	var inputter = document.getElementById("lcly-location-switcher-input-0");
	var inputText = inputter.value.toString(); 
	lcly_jsonp_script_0(inputText);
};
	function lcly_hide_suggest_0(e) {
		var newTarget = e.relatedTarget;
		if (newTarget !== undefined && newTarget !== null) {
			if(newTarget.className === 'lcly-autocomplete-anchor'
				|| newTarget.className === 'lcly-location-switcher-input'
				) {
				return;
			}
		}
		var list = document.getElementById('lcly-suggestions-autocomplete');
		list.innerHTML = '';
	}

	function lcly_use_my_location_0() {
		navigator.geolocation.getCurrentPosition(function (position) {
			lcly_reload_0({ 'location_change_to_string' : 'coords:' + position.coords.latitude + ',' + position.coords.longitude});
		}, function (error) {
			console.log(error);
			alert('Sorry your browser could not provide a location. You may need to enable location services for this browser. Or try typing the name of your location here instead.');
			document.getElementById('lcly-location-switcher-input-0').value = '';
			document.getElementById('lcly-location-switcher-input-0').focus();
		}, {
			enableHighAccuracy: true
		});
	}

	document.getElementById('lcly-location-switcher-input-0').onfocus = function() {
		var cur_val = document.getElementById('lcly-location-switcher-input-0').value;
		if(cur_val === '') {
			lcly_get_script_callback_0({suggestions: [{value: '⌖ Use My Location'}]});
		} else {
			var suggestions = document.getElementById('lcly-suggestions-autocomplete');
			if(suggestions && (suggestions.innerHMTL === '' || suggestions.innerHMTL === undefined)) {
				lcly_jsonp_script_0(cur_val);
			}
		}
	}

	document.getElementById('lcly-location-switcher-input-0').onblur = lcly_hide_suggest_0;

	
	document.getElementById('lcly-location-switcher-input-0').addEventListener("keydown", function(e) {
		var code = e.keyCode ? e.keyCode : e.charCode;
		if (code === 40 || code === 13) {
			e.preventDefault();
			var target = document.getElementById("lcly-autocomplete-a" + 0);
			if(target) {
				target.focus();
			}
		}
	});

	document.getElementById('lcly-location-switcher-0').onsubmit = function(){
		lcly_city_placeholder = document.getElementById('lcly-location-switcher-input-0').value;
		if (lcly_city_placeholder[0] === '⌖') {
			lcly_use_my_location_0();
			return false;
		}

		document.getElementById('lcly-location-switcher-input-0').placeholder = lcly_city_placeholder;

		lcly_reload_0({ 'location_change_to_string' : document.getElementById('lcly-location-switcher-input-0').value });
		return false;
	};

			document.getElementById('lcly-location-prompt-link-0').onclick = function(){
			document.getElementById('lcly-location-prompt-0').style.display = 'none';
			document.getElementById('lcly-location-switcher-0').style.display = 'block';
			document.getElementById('lcly-location-switcher-input-0').focus();
		}
	

	var lcly_dealers_wrap_0 = document.createElement('div');
	lcly_dealers_wrap_0.className = 'lcly-dealers-wrap-outer lcly-toggleable-0';
	lcly_dealers_wrap_0.innerHTML = '<div id="lcly-dealers-0" class="lcly-dealers-wrap lcly-tab-content-0"><div class="lcly-no-dealers"><p>This selection is not available near you. Please change your selection or change your location to see more options.</p></div></div>';
	lcly_parent_0.insertBefore(lcly_dealers_wrap_0, lcly_link_0);
	
	var lcly_dealers_0 = document.getElementsByClassName('lcly-dealer-0');

			for (var i = 0 ; i < lcly_dealers_0.length ; i++){
			lcly_dealers_0[i].onkeydown = function(e) {
				if (e.keyCode == 13 && e.target.id === this.id) { 
					this.click(); 
				}
			}

			lcly_dealers_0[i].onclick  = function(){ 
				
				var conversion_url = this.getAttribute('data-conversion-url');

				if (conversion_url != ''){

					lcly_query_string_0 = '';
					lcly_endpoint_0     = 'https://www.locally.com' + conversion_url;
					lcly_modal_title_0  = lcly_orig_modal_title_0;

				} else {

					lcly_query_string_0 = lcly_orig_query_string_0;
					lcly_endpoint_0     = lcly_orig_endpoint_0;
					lcly_modal_title_0  = lcly_orig_modal_title_0;
				}

				lcly_fixed_width_0 = false;
				lcly_fixed_height_0 = false;
				
				if (conversion_url && conversion_url.indexOf('product_id=') > -1 && lcly_launch_pl_v3) {
					window.lclyInlineModalGlobal(this.getAttribute('data-query-string'), lcly_orig_query_string_obj_0 );
				} else {
					lcly_modal_launch_0();
				}
			};
		}
	


	
		lcly_button_0.innerHTML = '<span><svg xmlns="http://www.w3.org/2000/svg" style="display: none;"><symbol id="icon-locally-outline" viewBox="0 0 512 512"><path d="m148 122c-2 0-2 0-4 0-10 0-20 2-29 6-8 4-18 9-24 16-23 23-29 58-16 88 12 28 41 47 73 47 11 0 22-2 31-7 20-8 34-24 41-43 8-20 8-41-1-61-12-28-41-46-71-46z m53 98c-5 15-16 25-30 32-8 3-15 4-23 4-23 0-43-13-53-33-10-22-4-47 12-64 5-5 11-10 18-12 7-3 13-4 21-4l2 0c23 0 43 13 53 33 5 15 6 30 0 44z m221-153c-20-9-41-13-61-13-40 0-77 16-105 45-28-29-64-45-105-45-20 0-41 4-61 13-57 26-88 74-90 129-1 24 4 51 15 77 50 113 230 182 237 184 2 0 3 2 5 2 1 0 2 0 4-2 8-3 187-73 236-185 36-84 5-169-75-205z m-172 365c-38-17-175-79-214-168-10-23-15-45-15-66 2-47 29-88 76-111 18-7 37-10 54-10 37 0 71 16 96 47l1 1c9 11 17 23 22 37 41 88-5 231-20 270z m226-168c-37 82-152 141-202 163 13-34 32-103 33-172 7 7 15 13 24 17 10 4 21 6 32 6 31 0 59-18 73-48 13-29 6-64-16-87-7-8-15-13-25-18-8-4-18-6-28-6l-4 0c-29 0-55 16-69 41 0-2-2-6-4-9-2-4-3-7-6-10-4-9-10-18-14-25 24-26 55-41 90-41 18 0 35 4 52 11 71 32 96 105 64 178z m-165-87c9-21 30-33 53-33l2 0c8 0 14 1 21 4 6 3 12 6 18 12 17 16 22 41 12 63-9 21-29 35-53 35-8 0-15-1-23-4-14-7-25-18-30-31-6-17-6-33 0-46z"/></symbol></svg><svg class="icon-locally-outline"><use xlink:href="#icon-locally-outline"></use></svg></span>'; 
		lcly_button_0.style.cursor = 'pointer';
		
				
	


	
	lcly_button_0.onclick = function(){ 
	
		lcly_query_string_0 = lcly_orig_query_string_0;
		lcly_endpoint_0     = lcly_orig_endpoint_0;
		lcly_modal_title_0  = lcly_orig_modal_title_0;	
		
		if (lcly_query_has_product_0 && lcly_launch_pl_v3) {
			window.lclyInlineModalGlobal(lcly_query_string_0, lcly_orig_query_string_obj_0)
		} else {
			lcly_modal_launch_0();
		}
	};






	lcly_link_0.innerHTML = 'show all local options';
	lcly_link_0.setAttribute('data-switchlive' , 'true');
	lcly_link_0.setAttribute('data-switchlive-mode' , 'auto');
	lcly_link_0.setAttribute('data-switchlive-id-pl', '6');
	lcly_link_0.onclick = function(event){
		lcly_query_string_0 = lcly_orig_query_string_0;
		lcly_endpoint_0     = lcly_orig_endpoint_0;
		lcly_modal_title_0  = lcly_orig_modal_title_0;	
		if (lcly_query_has_product_0 && lcly_launch_pl_v3) {
			window.lclyInlineModalGlobal(lcly_query_string_0, lcly_orig_query_string_obj_0)
		}
		else {
			lcly_modal_launch_0();
		}
		event.preventDefault();
		return false;
	}


	var lcly_directions_links_0 = document.getElementsByClassName('lcly-directions-link-0');
	for (var i = 0 ; i < lcly_directions_links_0.length ; i++){
		lcly_directions_links_0[i].onclick = function(event){
			window.open(this.getAttribute('href'));
			event.stopPropagation();
			event.preventDefault();
		};
	}




var lcly_reload_0 = function(params){

	var cachebuster                 = Math.round(new Date().getTime() / 1000);
	params.v 						= cachebuster;
	params.is_reload 				= 1;
	var old_script                  = document.getElementById('lcly-script-0');
	var new_script                  = document.createElement('script');
	var new_params                  = typeof params.refresh != 'undefined' ? params : lcly_merge_0(lcly_orig_query_string_obj_0, params);

	delete new_params.product_id;
	
	var new_query_string            = lcly_serialize_0(new_params);

	if(old_script !== null && old_script != undefined) {
		if (old_script.parentNode.id.indexOf('lcly-button') > -1){ // script tag is within the container :0 - it's malformed.

			old_script.parentNode.parentNode.insertBefore(new_script, old_script.parentNode);
			old_script.parentNode.removeChild(old_script);
			
		} else { // do the standard reload

			old_script.parentNode.insertBefore(new_script, old_script);
			old_script.parentNode.removeChild(old_script);
		}
	} else {
		// couldn't found our script? insert into head
		console.log('Locally Error: could not locate script tag to update locally script');
		const head_list = document.getElementsByTagName('head');
		if(head_list.length === 1) {
			head_list[0].appendChild(new_script);
			
		} else {
			console.log('Locally Error: could not locate head tag');
		}
	}

	lcly_parent_0.innerHTML = '<a id="lcly-link-0"></a>';
	new_script.setAttribute('src', 'https://trek.locally.com/stores/map.js?' + new_query_string);
	new_script.setAttribute('id', 'lcly-script-0');
}

var lcly_serialize_0 = function(obj) {

  var str = [];
  for(var p in obj)
    if (obj.hasOwnProperty(p)) {
      str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
    }
  return str.join("&");
}

var lcly_merge_0 = function(obj, src) {

    for (var key in src) {
        if (src.hasOwnProperty(key)) obj[key] = src[key];
    }
    return obj;
}
var lcly_overlay_0       = null;
var lcly_fixed_width_0   = false;
var lcly_fixed_height_0  = false;
var lcly_event_method_0  = window.addEventListener ? "addEventListener" : "attachEvent";
var lcly_eventer_0       = window[lcly_event_method_0];
var lcly_message_event_0 = lcly_event_method_0 == "attachEvent" ? "onmessage" : "message";
var lcly_endpoint_0 	 = 'https://trek.locally.com/stores/map/embedded?action=convert';
var lcly_modal_title_0   = '';
var lcly_native_viewport 		 = false;
var lcly_min_supported_height	 = 600;
var lcly_body_0 = document.getElementsByTagName('body')[0];

if (typeof window.lcly_orig_scroll_padding_top === 'undefined') {
	window.lcly_orig_scroll_padding_top = '0px';
}

// Polyfill to support CustomEvent in IE11
(function () {
  if ( typeof window.CustomEvent === "function" ) return false; //If not IE

  function CustomEvent ( event, params ) {
    params = params || { bubbles: false, cancelable: false, detail: undefined };
    var evt = document.createEvent( 'CustomEvent' );
    evt.initCustomEvent( event, params.bubbles, params.cancelable, params.detail );
    return evt;
   }

  CustomEvent.prototype = window.Event.prototype;

  window.CustomEvent = CustomEvent;
})();

lcly_eventer_0(lcly_message_event_0, function(e) {
	if (typeof e.data.affiliate_redirect != 'undefined') {
		window.open('https://trek.locally.com' + e.data.affiliate_redirect, '_blank');
	}

	if (typeof e.data.start_conversion_query != 'undefined'){

		lcly_query_string_0 = e.data.start_conversion_query;
		if (e.data.start_conversion_title != '') lcly_modal_title_0 = e.data.start_conversion_title ;
		if (e.data.start_conversion_endpoint != '') lcly_endpoint_0 = e.data.start_conversion_endpoint ;
		if (e.data.start_conversion_query != '') lcly_query_string_0 = e.data.start_conversion_query;
		lcly_modal_launch_0();

	} else if (typeof e.data.requestor != 'undefined' && e.data.requestor == 'widget' && typeof lcly_element_0 != 'undefined' && typeof lcly_body_0 != 'undefined' ) {
		
		lcly_element_0.style.height = (e.data.height + 100) + 'px';

		if(e.data.is_fullscreen != undefined && e.data.is_fullscreen){
			lcly_element_0.style.position = 'fixed';
			lcly_element_0.style.top = '0';
			lcly_element_0.style.bottom = '0';
			lcly_element_0.style.left = '0';
			lcly_element_0.style.right = '0';
			lcly_element_0.style.zIndex = '99999999999999';
			lcly_element_0.style.backgroundColor = '#fff';
			lcly_body_0.style.overflow = 'hidden';

			var iframes = document.getElementsByTagName('iframe');
			var iframesArray = Array.prototype.slice.call(iframes);

			if (iframes != null && typeof iframes != 'undefined' && iframes.length > 0){
				iframesArray.forEach(function(thisFrame){
					if (thisFrame == lcly_element_0){
						return;
					}
					var lcly_orig_opacity = thisFrame.style.opacity;										
					thisFrame.style.opacity = '0';
					thisFrame.setAttribute('lcly_orig_opacity', lcly_orig_opacity);						
				});
			}

		} else{
			lcly_element_0.style.position = '';
			lcly_element_0.style.top = '';
			lcly_element_0.style.bottom = '';
			lcly_element_0.style.left = '';
			lcly_element_0.style.right = '';
			lcly_element_0.style.zIndex = '';
			lcly_element_0.style.backgroundColor = '';
			lcly_body_0.style.overflow = '';

			var iframes = document.getElementsByTagName('iframe');
			var iframesArray = Array.prototype.slice.call(iframes);

			if ( iframes != null && !typeof iframes != 'undefined' && iframes.length > 0 ){				
				iframesArray.forEach(function(thisFrame){
					if (thisFrame == lcly_element_0){
						return;
					}
					var lcly_orig_opacity = thisFrame.getAttribute('lcly_orig_opacity');
					if (typeof lcly_orig_opacity != 'undefined'){
						thisFrame.style.opacity = lcly_orig_opacity;
					}	
				});
			}	
		}

		lcly_element_0.style.height = e.data.height;//debugger;
		if (!e.data.change_url) return false;

		if (e.data.document_path.indexOf('http://') > -1 || e.data.document_path.indexOf('https://') > -1){

			window.open(e.data.document_path);

		} else {

			lcly_element_0.src = 'https://trek.locally.com' + e.data.document_path;
			window.location = '#' + e.data.document_path;
			window.scroll(0,lcly_find_y_pos(lcly_element_0) - 100);
		}

	} else if (typeof e.data.broadcast != 'undefined') {

		var lcly_event_name = 'LOCALLY_' + e.data.broadcast.name;
		var lcly_broadcast_data = e.data.broadcast.data;
		var lcly_event = new CustomEvent(lcly_event_name, { detail: lcly_broadcast_data } );
		window.dispatchEvent(lcly_event);

	} else if (typeof e.data.geolocate != 'undefined') {

		lcly_geo_locate_0();
	} else if (typeof e.data.scroll_top != 'undefined') {
		setTimeout(function() {
			var scroll_padding_top = document.documentElement.style.scrollPaddingTop;
			if (scroll_padding_top && window.lcly_orig_scroll_padding_top === '0px') {
				window.lcly_orig_scroll_padding_top = scroll_padding_top;
				document.documentElement.style.scrollPaddingTop = '0px';
			}
			
			var modal_frame = document.getElementById("lcly-iframe-outer-0");
			if (modal_frame) {
				setTimeout(function() {
					modal_frame.scrollIntoView();
				}, 0);
			}
		}, 300);
	} else { // it's a state change 

		if (typeof e.data.width != 'undefined') lcly_fixed_width_0 = e.data.width.toString().replace('px', '');
		if (typeof e.data.height != 'undefined' && e.data.height > 100) lcly_fixed_height_0 = e.data.height.toString().replace('px', '');
		lcly_audit_size_0();
	}

}, false);

function lcly_modal_launch_0(){	
	
	
	var lcly_scrollTop = (window.pageYOffset !== undefined) ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop;

	lcly_overlay_0     = document.createElement('div');
	lcly_overlay_0.id  = 'lcly-overlay-0';

	var lcly_body_0 = document.getElementsByTagName('body')[0],
		lcly_w = window;
	lcly_body_0.appendChild(lcly_overlay_0);

	if (lcly_w.innerHeight > lcly_min_supported_height){
		lcly_body_0.style.overflow = "hidden";
	}
	lcly_add_class_0(lcly_body_0, 'lcly-active');

	lcly_set_viewport_0(false);
	var iframe_query_string = lcly_query_string_0 + '&host_domain=' + document.domain;

	var lcly_html_0 = 

		'<div id="lcly-iframe-outer-0" style="position: absolute; left: 0; z-index: 99999; width: 100%; height: 100%; top: ' + lcly_scrollTop + 'px !important;" onclick="lcly_remove_0()" tabindex="0">'
			+ '<a id="lcly-iframe-closer-0" tabindex="0" '
			+   'title="Close Retailers" '
			+   'aria-label="Close Retailers" '
			+   'href="javascript:;" style="position: absolute; top: 10px; width: 50px; height: 50px; text-indent: -9999px; background: url(https://trek.locally.com/img/modal-x.png) no-repeat 50% 50%; background-size: 50%; z-index: 99;right: 15px;"></a>'
			+ '<div id="lcly-iframe-0" onclick="lcly_prevent_bubbling_0()" style="width: 70%; height: 80%; margin: 100px auto;">'
			   + '<iframe id="lcly-iframe-inner-0" title="Retailers / Where to Buy" '
			    + 'scrolling="no" frameborder="0" '
				+ 'src="' + lcly_endpoint_0 + '&' + iframe_query_string + '#/?' + iframe_query_string + '" '
				+ 'style="width: 100%; height: 600px; margin: 0 auto;">'
			   + '</iframe>'
			+ '</div>'
		+ '</div>'
		+ '<div class="lcly-screen" style="top: 0; left: 0; width: 100%; height: 100%; z-index: 9999; overflow: hidden; position: fixed; background: #312e2e; opacity: 0.9; filter: alpha(opacity=90);"></div>';

	lcly_overlay_0.innerHTML = lcly_html_0;
	lcly_audit_size_0();

	// initiate accessibility
	var lcly_iframe_outer_0 = document.getElementById('lcly-iframe-outer-0');
	lcly_iframe_outer_0.focus();
}

function lcly_remove_0(){
	lcly_set_viewport_0(true);
	lcly_overlay_0.parentNode.removeChild(lcly_overlay_0);
	var lcly_body_0 = document.getElementsByTagName('body')[0];
	lcly_body_0.style.overflow = "";
	lcly_remove_class_0(lcly_body_0, 'lcly-active');

	if (window.lcly_orig_scroll_padding_top !== '0px') {
		document.documentElement.style.scrollPaddingTop = window.lcly_orig_scroll_padding_top;
		window.lcly_orig_scroll_padding_top = '0px';
	}
}

function lcly_prevent_bubbling_0(e){
	e.stopPropagation();
}

function lcly_set_viewport_0(remove){
	
	var lcly_viewport = document.querySelector("meta[name=viewport]");

	if (remove){

		if (!lcly_viewport) return false;
		lcly_viewport.setAttribute('content', lcly_native_viewport ? lcly_native_viewport : '');

	} else {

		if (lcly_viewport){
			
			lcly_native_viewport = lcly_viewport.getAttribute('content');
			lcly_viewport.setAttribute('content', 'width=device-width initial-scale=1.0 minimum-scale=1.0');
		
		} else {

			var lcly_meta_tag = document.createElement('meta');
			lcly_meta_tag.name = "viewport"
			lcly_meta_tag.content = "width=device-width, initial-scale=1.0"
			document.getElementsByTagName('head')[0].appendChild(lcly_meta_tag);
		}
	}
}

function lcly_audit_size_0(){

	var lcly_w = window,
	    lcly_d = document,
	    lcly_e = lcly_d.documentElement,
	    lcly_g = lcly_d.getElementsByTagName('body')[0],
	    lcly_x = lcly_g.clientWidth,
	    lcly_y = lcly_g.clientHeight;

	var lcly_iframe					= document.getElementById('lcly-iframe-0');
	var lcly_iframe_inner			= document.getElementById('lcly-iframe-inner-0');
	var lcly_embedded_iframe 		= document.getElementById('lcly-embedded-iframe-inner-0');
	var lcly_target_width 			= lcly_w.innerWidth < 960 ? lcly_w.innerWidth - 40 : lcly_w.innerWidth - 160;

	if (lcly_iframe) {

		lcly_width						= lcly_fixed_width_0 ? lcly_fixed_width_0 : lcly_target_width;
		// set lcly_height to min supported height, unless window is bigger than min supported height, then scale window using value from "eventer"
		lcly_height						= lcly_min_supported_height;
		if (lcly_w.innerHeight > lcly_min_supported_height){
			lcly_height					= lcly_fixed_height_0 ? lcly_fixed_height_0 : lcly_w.innerHeight - 140;
		}

		lcly_iframe.style.width			= lcly_width + 'px';
		lcly_iframe.style.height		= lcly_height + 'px';
		lcly_iframe.style.marginTop		= "70px";
		lcly_iframe.style.marginBottom  = "70px";
		lcly_iframe_inner.style.width	= lcly_width + 'px';
		lcly_iframe_inner.style.height	= lcly_height + 'px';
	}

	}

function lcly_has_class_0(ele,cls) {
  return !!ele.className.match(new RegExp('(\\s|^)'+cls+'(\\s|$)'));
}

function lcly_add_class_0(ele,cls) {
  if (!lcly_has_class_0(ele,cls)) ele.className += " "+cls;
}

function lcly_remove_class_0(ele,cls) {
  if (lcly_has_class_0(ele,cls)) {
    var reg = new RegExp('(\\s|^)'+cls+'(\\s|$)');
    ele.className=ele.className.replace(reg,' ');
  }
}

window.onresize = function() {

    lcly_audit_size_0();
}

/* GEO-LOCATION METHODS */

function lcly_geo_locate_0(){
	
	if (navigator.geolocation) {
    	navigator.geolocation.getCurrentPosition(lcly_geo_locate_success_0, lcly_geo_locate_error_0);
  	} else {
  		alert("Sorry, your browser doesn't support geolocation.");
  	}
}

function lcly_geo_locate_success_0(position){

	var lcly_embedded_iframe = document.getElementById('lcly-embedded-iframe-inner-0');
	lcly_embedded_iframe = !lcly_embedded_iframe ? document.getElementById('lcly-iframe-inner-0') : lcly_embedded_iframe;

	lcly_embedded_iframe.contentWindow.postMessage({ lat : position.coords.latitude, lng : position.coords.longitude }, "*");
}

function lcly_geo_locate_error_0(error){

	alert('Sorry your browser could not provide a location. You may need to enable location services for this browser. Or try typing the name of your location here instead.');
}


var lcly_event_data = { 
	id : '0',
	n_items_with_stock : 0,
	n_items_stocking_product : 0,
	n_items_stocking_upc : 0,
	dealers: false,
	product_id: 1311317
};

var lcly_event = new CustomEvent('LOCALLY_data_update', { detail: lcly_event_data } );
window.dispatchEvent(lcly_event);


var lcly_markup_city_tags_0 = document.getElementsByClassName('lcly-city-name');
for (var x = 0 ; x < lcly_markup_city_tags_0.length ; x++){
	lcly_markup_city_tags_0[x].innerHTML = ", Hong Kong Island";
}

	window.lcly_switchlive_context = 'PL';
	/**
 * SwitchLive Message Listener
 */

if (typeof window.receiveSwitchLiveEvent != 'function'){
    window.receiveSwitchLiveEvent = function( eventMessage ){
        if (typeof eventMessage.data.message_type != 'undefined' && eventMessage.data.message_type == 'switchlive'){
            var switchLiveEvent = eventMessage.data;
            switchLiveEventCallback( switchLiveEvent );
        }
    }
}
window.addEventListener("message", window.receiveSwitchLiveEvent, false);

if(typeof switchLiveEventCallback != 'function'){
    window.switchLiveEventCallback = function( switchLiveEvent ){
        /* custom implementation by brand goes in a function with this name. */
        // console.info("Locally SwitchLive is enabled.  No switchLiveEventCallback() function was provided.");
        // console.info( switchLiveEvent );
    };
};

if (lcly_launch_pl_v3) {
	
        if (!document.getElementById('__lcly_inline_modal')) {
            {
                var lclyEmbedRoot = document.createElement('div');
                lclyEmbedRoot.setAttribute('id', '__lcly_inline_modal');
                document.body.appendChild(lclyEmbedRoot);
            }
        }

        if(typeof includeCss !== 'function') {
            function includeCss(cssFilePath) {
                var head  = document.getElementsByTagName('head')[0];
                var link  = document.createElement('link');
                link.rel  = 'stylesheet';
                link.type = 'text/css';
                link.href = cssFilePath;
                link.media = 'all';
                head.appendChild(link);
            }
        }
        
        if(typeof includeJs !== 'function') {
            function includeJs(jsFilePath, id) {
                var __lcly_script = document.getElementById(id);

                if (!__lcly_script) {
                    var js = document.createElement('script');
                    
                    js.id = id;
                    js.type = 'text/javascript';
                    js.src = jsFilePath;
                    js.async = true;
                
                    document.body.appendChild(js);
                }
            }
        }
        
        includeJs('https://frontend2.locally.com/inline_modal/main.js?ver=c9649e5', '__lcly_script_inline_modal')

        
}
